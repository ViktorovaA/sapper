import pygame
import def_load_image
import class_Game
import class_Bomb
import def_start_screen
import def_rules


# проверка выбора игрока в меню
def check_start_screen():
    mode = 4
    while mode == 4:
        mode = def_start_screen.start_screen(screen)
        if mode == 4:
            mode = def_rules.rules(screen)
        if mode == 1:
            boardd = class_Game.Game(7, 7, 5, screen)
            boardd.set_view(80, 125, 50)
        elif mode == 2:
            boardd = class_Game.Game(10, 10, 10, screen)
            boardd.set_view(30, 50, 50)
        elif mode == 3:
            boardd = class_Game.Game(15, 15, 20, screen)
            boardd.set_view(60, 75, 30)
    return boardd


pygame.init()
size = 1000, 600
screen = pygame.display.set_mode(size)
clock = pygame.time.Clock()

image_start = def_load_image.load_image('game.jpg')
image_end = def_load_image.load_image('end.jpg')
image_win = def_load_image.load_image('win.jpg')
image = image_start
screen.blit(image, (0, 0))

# Включено ли обновление поля
time_on = False
ticks = 0

# анимация
all_sprites = pygame.sprite.Group()

for i in range(1):
    class_Bomb.Bomb(all_sprites)

# событие анимации
MYEVENTTYPE = 30
a = False
running_bomb = False    # выключение анимвции
pygame.time.set_timer(MYEVENTTYPE, 1000)

running = True
# меню
board = check_start_screen()

while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        if event.type == pygame.KEYDOWN:
            # новая игра при оканчании предыдущей
            if event.key == pygame.K_SPACE and (board.status == 'win' or board.status == 'fail'):
                board.new_game()
                a = False
            # переход в меню
            elif event.key == pygame.K_1:
                board = check_start_screen()
        if event.type == pygame.MOUSEBUTTONDOWN and board.status == 'game':
            # mode == 1 - левая кнопка мыши; 3 - правая
            if event.button == 1:
                board.get_click(event.pos, 1)
            elif event.button == 3:
                board.get_click(event.pos, 3)
        # смена картинки анимации
        if event.type == MYEVENTTYPE and running_bomb:
            a = True
            all_sprites.update(a)

    # смена картинки в зависимости от этапа игры
    if board.status == 'fail':
        image = image_end
        # включение анимации
        running_bomb = True
    elif board.status == 'win':
        image = image_win
    else:
        image = image_start
        running_bomb = False

    screen.blit(image, (0, 0))
    board.render()

    if running_bomb:
        all_sprites.update(a)
        all_sprites.draw(screen)
    pygame.display.flip()

    clock.tick(50)
    ticks += 1
pygame.quit()
