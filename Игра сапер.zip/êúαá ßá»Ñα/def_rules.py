import pygame
import sys
import def_load_image
import def_start_screen


pygame.init()
FPS = 50
clock = pygame.time.Clock()


# экстренный выход???
def terminate():
    pygame.quit()
    sys.exit()


# правила
def rules(screen):
    fon = def_load_image.load_image('rules.jpg')
    screen.blit(fon, (0, 0))

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                terminate()
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE:
                    return def_start_screen.start_screen(screen)
        pygame.display.flip()
        clock.tick(FPS)