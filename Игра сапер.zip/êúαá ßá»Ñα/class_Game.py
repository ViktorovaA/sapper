import class_Board
import random
import pygame


pygame.init()


# класс минного поля
class Game(class_Board.Board):
    def __init__(self, width, height, n, screen):
        super().__init__(width, height, screen)
        # сначала все клетки закрыты
        self.n = n            # количество бомб
        self.bombs = 0        # количество помеченных кружками клеток
        self.status = 'game'  # этап игры
        self.board = []
        self.new_game()

    # новая игра
    def new_game(self):
        self.status = 'game'
        self.bombs = 0
        self.board = [-1] * self.height
        for i in range(self.height):
            self.board[i] = [-1] * self.width
        # заполнение поля бомбами
        i = 0
        while i < self.n:
            x = random.randint(0, self.width - 1)
            y = random.randint(0, self.height - 1)
            # чтобы две бомбы рядом не стояли
            s = 0
            for dy in range(-1, 2):
                for dx in range(-1, 2):
                    if x + dx < 0 or x + dx >= self.width or y + dy < 0 or y + dy >= self.height:
                        continue
                    if self.board[y + dy][x + dx] == 10:
                        s += 1
                        break
            if self.board[y][x] == -1 and s == 0:
                self.board[y][x] = 10
                i += 1

    def open_cell(self, cell, mode=1):
        x, y = cell
        # -1 = пустая неоткрытая клетка
        # 0; 1; 2... = открытая клетка с количеством бомб вокруг
        # 11 = помеченная клетка с бомбой
        # 12 = помеченная клетка без бомбы
        # mode == 1 = левая кнопка мыши; 3 = правая
        # проверяем на бомбу
        if mode == 1 and (self.board[y][x] == 10 or self.board[y][x] == 11):
            for i in range(self.height):
                for j in range(self.width):
                    if self.board[i][j] == 11:
                        self.board[i][j] = 10
            self.status = 'fail'
            return
        # установка или снятие кружка
        if mode == 3:
            c = 0
            for i in range(self.height):
                for j in range(self.width):
                    if self.board[i][j] == 11 or self.board[i][j] == 12:
                        c += 1
            if self.board[y][x] == -1 and c < self.n:
                self.board[y][x] = 12
                self.bombs += 1
                self.check()
                return
            elif self.board[y][x] == 10 and c < self.n:
                self.board[y][x] = 11
                self.bombs += 1
                self.check()
                return
            elif self.board[y][x] == 12:
                self.board[y][x] = -1
                self.bombs -= 1
                self.check()
                return
            elif self.board[y][x] == 11:
                self.board[y][x] = 10
                self.bombs -= 1
                self.check()
                return
            return

        # подсчет бомб вокруг
        s = 0
        if self.board[y][x] != 10 and self.board[y][x] != 11:
            for dy in range(-1, 2):
                for dx in range(-1, 2):
                    if x + dx < 0 or x + dx >= self.width or y + dy < 0 or y + dy >= self.height:
                        continue
                    if self.board[y + dy][x + dx] == 10 or self.board[y + dy][x + dx] == 11:
                        s += 1
            self.board[y][x] = s

            if s == 0 and mode == 1:
                # рекурсивно открываем остальные клетки
                for dy in range(-1, 2):
                    for dx in range(-1, 2):
                        if x + dx < 0 or x + dx >= self.width or y + dy < 0 or y + dy >= self.height:
                            continue
                        if self.board[y + dy][x + dx] == -1:
                            self.open_cell((x + dx, y + dy))
        # проверка вытгрыша
        self.check()

    def on_click(self, cell, mode=1):
        self.open_cell(cell, mode)

    def get_click(self, mouse_pos, mode=1):
        cell = self.get_cell(mouse_pos)
        if cell:
            self.on_click(cell, mode)

    # трисовка поля
    def render(self):
        for y in range(self.height):
            for x in range(self.width):
                if self.status == 'fail' and self.board[y][x] == 10:
                    pygame.draw.rect(self.screen, (230, 30, 10),
                                     (x * self.cell_size + self.left, y * self.cell_size + self.top, self.cell_size,
                                      self.cell_size))

                elif 11 > self.board[y][x] >= 0 and self.board[y][x] != 10:
                    font = pygame.font.Font(None, self.cell_size - 6)
                    if self.board[y][x] == 0:
                        text = font.render('', 1, (70, 0, 70))
                    else:
                        text = font.render(str(self.board[y][x]), 1, (70, 0, 70))
                    self.screen.blit(text, (x * self.cell_size + self.left + 3, y * self.cell_size + self.top + 3))

                else:
                    pygame.draw.rect(self.screen, (150, 180, 150),
                                     (x * self.cell_size + self.left, y * self.cell_size + self.top, self.cell_size,
                                      self.cell_size))

                if self.board[y][x] == 11 or self.board[y][x] == 12:
                    pygame.draw.ellipse(self.screen, (150, 30, 10), (x * self.cell_size + self.left + 3,
                                                                     y * self.cell_size + self.top + 3,
                                                                     self.cell_size - 6, self.cell_size - 6))

                pygame.draw.rect(self.screen, pygame.Color('black'),
                                 (x * self.cell_size + self.left, y * self.cell_size + self.top, self.cell_size,
                                  self.cell_size), 1)

                self.show_bombs_value()

    # показывает, сколько осталость помеченных клеток
    def show_bombs_value(self):
        font = pygame.font.Font(None, 40)
        text = font.render('осталось бомб - ' + str(self.n - self.bombs), 1, pygame.Color('black'))
        self.screen.blit(text, (640, 500))

    # проверка на выигрыш
    def check(self):
        c = 0
        for i in self.board:
            for j in i:
                if j == 11:
                    c += 1
        if c == self.n:
            self.status = 'win'
