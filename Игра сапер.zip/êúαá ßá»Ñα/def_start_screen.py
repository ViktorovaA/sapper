import pygame
import sys
import def_load_image


pygame.init()
FPS = 50
clock = pygame.time.Clock()


# экстренный выход???
def terminate():
    pygame.quit()
    sys.exit()


# меню
def start_screen(screen):
    fon = def_load_image.load_image('start.jpg')
    screen.blit(fon, (0, 0))

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                terminate()
            # выбор игрока
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_1:
                    return 1
                elif event.key == pygame.K_2:
                    return 2
                elif event.key == pygame.K_3:
                    return 3
                elif event.key == pygame.K_SPACE:
                    return 4
        pygame.display.flip()
        clock.tick(FPS)
