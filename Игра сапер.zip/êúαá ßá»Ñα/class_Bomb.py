import random
import def_load_image
import pygame


size = width, height = 500, 500
screen = pygame.display.set_mode(size)


# анимация бомбы
class Bomb(pygame.sprite.Sprite):
    image = def_load_image.load_image('bomb.png')
    image_boom = def_load_image.load_image('boom2.png')

    def __init__(self, group):
        super().__init__(group)
        self.image = Bomb.image
        self.rect = self.image.get_rect()
        self.rect.x = 140
        self.rect.y = 170

    # смена картинки
    def update(self, a=False):
        if a is False:
            self.image = Bomb.image
            self.rect = self.rect.move(random.randrange(3) - 1, random.randrange(3) - 1)
        if a:
            self.image = self.image_boom
